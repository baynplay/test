#!/bin/bash

if [ -x /opt/google/chrome/google-chrome ]; then
    /opt/google/chrome/google-chrome --start-maximized --disable-translate --disable-new-tab-first-run --no-default-browser-check --no-first-run --kiosk --app="https://www.netflix.com/browse" &
elif [ -x /usr/bin/google-chrome ]; then
    /usr/bin/google-chrome --start-maximized --disable-translate --disable-new-tab-first-run --no-default-browser-check --no-first-run --kiosk --app="https://www.netflix.com/browse" &
fi
CHROME_PID=$!
wait $CHROME_PID
