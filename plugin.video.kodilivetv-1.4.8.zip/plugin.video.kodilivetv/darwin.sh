#!/bin/sh

"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" --koisk --start-fullscreen "https://www.netflix.com/browse" &
CHROME_PID=$!

wait $CHROME_PID

