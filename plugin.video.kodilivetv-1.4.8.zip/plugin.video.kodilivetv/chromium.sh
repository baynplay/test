#!/bin/bash

if [ -x /usr/bin/chromium ]; then
    /usr/bin/chromium --start-maximized --disable-translate --disable-new-tab-first-run --no-default-browser-check --no-first-run --kiosk --app="https://www.netflix.com/browse" &
elif [ -x /usr/bin/chromium-browser ]; then
    /usr/bin/chromium-browser --start-maximized --disable-translate --disable-new-tab-first-run --no-default-browser-check --no-first-run --kiosk --app="https://www.netflix.com/browse" &
fi
CHROME_PID=$!
wait $CHROME_PID
