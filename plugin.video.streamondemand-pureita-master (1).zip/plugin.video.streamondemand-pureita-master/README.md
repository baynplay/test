# Stream On Demand PureITA

![alt tag] (https://raw.githubusercontent.com/Fenice82/plugin.video.streamondemand-pureita/master/icon.png)

Fork of Pelisalacarta-ui, fully translated and customized with only italian channels.

Made for touch devices and thinked to have the same User Interface on all your KODI\Openelec installations and skins.

Easily installable via Add-on manager on Kodi\Openelec, this version have self-updates enabled by default.

All the erotic channels were removed, KODI\Openelec repositories are full of add-on made to view this kind of contents.

Special thanks to forum users: Jesus (for pelisalacarta) robalo (for being a master and a skilled a developer) dentaku65 (for being a vulcano of ideas and a hard worker, and supporting moving the project here) DrZ3r0 (for being an Italian skilled developer, author of many important servers' files) Raùl (for his native general search) Chryses (for ideas about auto-updates) Zanzibar1982 (for editing channels and for adapting Pelisalacarta Classic to Streamondemand, https://github.com/Zanzibar82/plugin.video.streamondemand)

Also refer to forum: http://www.mimediacenter.info/foro/viewforum.php?f=36
